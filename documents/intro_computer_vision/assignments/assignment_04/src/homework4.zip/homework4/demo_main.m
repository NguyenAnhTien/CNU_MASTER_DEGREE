template = imread('/home/tiennguyen/Downloads/hand_template_02.png');
target = imread('/home/tiennguyen/Downloads/IMG_0267.JPG');

template = rgb2gray(template);
target = rgb2gray(target);
template = imresize(template, [22 26]);
target = imresize(target, [155 108]);

mean_template = template - mean(mean(template));

[r1,c1]=size(target);
[r2,c2]=size(template);

M = []
for i=1:(r1-r2+1)
    for j=1:(c1-c2+1)
        Nimage=target(i:i+r2-1,j:j+c2-1);
        M(i,j)= hausdorffDist(Nimage, mean_template);
    end 
end

result=plotbox(target,template,M);

figure,
subplot(2,2,1),imshow(template);title('template');
subplot(2,2,2),imshow(target);title('Target');
subplot(2,2,3),imshow(result);title('Matching Result using tmp');