
% main file 

close all
clear all


% read Template image
im1=imread('/home/tiennguyen/Downloads/hand_template_02.png');
%im1=imread('S.bmp');
%im1=imread('image1.jpg');

im1 = imresize(im1, [22 26]);
% read Traget Image
im2=imread('/home/tiennguyen/Downloads/IMG_0267.JPG');
%im2=imread('image2.jpg');
im2 = imresize(im2, [155 108]);

% apply templete matching using power of the image
result1=tmp(im1,im2);

figure,
subplot(2,2,1),imshow(im1);title('Template');
subplot(2,2,2),imshow(im2);title('Target');
subplot(2,2,3),imshow(result1);title('Matching Result using tmp');


% apply templete matching using DC components of the image
result2=tmc(im1,im2);

figure,
subplot(2,2,1),imshow(im1);title('Template');
subplot(2,2,2),imshow(im2);title('Target');
subplot(2,2,3),imshow(result2);title('Matching Result using tmc');